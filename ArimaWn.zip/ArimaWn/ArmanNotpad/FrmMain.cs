﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArmanNotpad
{
    public partial class Form1 : Form
    {
        bool Onsaved = false;
        string MyPass;
        string path;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveit = new SaveFileDialog();
                saveit.Filter = " *.ari | *.ari";
                saveit.ShowDialog();
                string path = saveit.FileName;
                string encStr = EncryptStringSample.StringCipher.Encrypt(txtMain.Text, MyPass);
                System.IO.File.WriteAllText(path, encStr);
            }
            catch
            {

                MessageBox.Show("Error executing");
            }
            
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            GetPass Gpass = new ArmanNotpad.GetPass();
            Gpass.ShowDialog();
            MyPass = Gpass.MyPass;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openit = new OpenFileDialog();
                openit.Filter = " *.ari | *.ari";
                openit.ShowDialog();
                string encStr = System.IO.File.ReadAllText(openit.FileName);
                txtMain.Text = EncryptStringSample.StringCipher.Decrypt(encStr, MyPass);
            }
            catch
            {

                MessageBox.Show("Error executing");
            }
            }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openit = new OpenFileDialog();
                openit.Filter = " *.ari | *.ari";
                openit.ShowDialog();
                string encStr = System.IO.File.ReadAllText(openit.FileName);
                txtMain.Text = EncryptStringSample.StringCipher.Decrypt(encStr, MyPass);
                Onsaved = true;
                path = openit.FileName;
            }
            catch
            {

                MessageBox.Show("Error executing");
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (Onsaved == false)
                {
                    SaveAs();
                }
                else
                {
                    string encStr = EncryptStringSample.StringCipher.Encrypt(txtMain.Text, MyPass);
                    System.IO.File.WriteAllText(path, encStr);
                }
            }
            catch
            {

                MessageBox.Show("Error executing");
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void setNewPassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetPass Gpass = new ArmanNotpad.GetPass();
            Gpass.ShowDialog();
            MyPass = Gpass.MyPass;
        }

        private void txtMain_TextChanged(object sender, EventArgs e)
        {

        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Green;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
        }

        private void arialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var arif = new Font("Arial", 12, System.Drawing.FontStyle.Bold);
            txtMain.Font = arif;
        }

        private void tahomaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var tahof = new Font("Tahoma", 12, System.Drawing.FontStyle.Bold);
            txtMain.Font = tahof;
        }

        private void mjNaskhiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var nasf = new Font("Mj_Naskhi", 12, System.Drawing.FontStyle.Bold);
            txtMain.Font = nasf;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            var f = txtMain.Font;
            var newFont = new Font(f.FontFamily, f.Size + 1, System.Drawing.FontStyle.Bold);
            txtMain.Font = newFont;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            var f = txtMain.Font;
            var newFont = new Font(f.FontFamily, f.Size - 1, System.Drawing.FontStyle.Bold);
            txtMain.Font = newFont;
        }

        private void redToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtMain.ForeColor = System.Drawing.Color.Red;
        }

        private void whiteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtMain.ForeColor = System.Drawing.Color.White;
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtMain.ForeColor = System.Drawing.Color.Black;
        }

        private void fontsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetPass Gpass = new ArmanNotpad.GetPass();
            Gpass.ShowDialog();
            MyPass = Gpass.MyPass;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            txtMain.Font = fd.Font;
            //var arif = new Font();
            //txtMain.Font = arif;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.txtMain.Clear();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveAs();
        }
        void SaveAs()
        {
            SaveFileDialog saveit = new SaveFileDialog();
            saveit.Filter = " *.ari | *.ari";
            saveit.ShowDialog();
            path = saveit.FileName;
            string encStr = EncryptStringSample.StringCipher.Encrypt(txtMain.Text, MyPass);
            System.IO.File.WriteAllText(path, encStr);
            Onsaved = true;
        }
    }
}
 